# FINDOMESTIC PAYMENTS

## Basic Info


## What it does


## Testing

### How to perform tests
To perform the tests navigate to te folder

**modules/findomestic_payments/dev**

and execute the command

- **composer phpunit-findomestic**
