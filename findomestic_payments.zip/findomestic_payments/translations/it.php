<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{findomestic_payments}prestashop>product-simulator-link_df573c5a3c3bfe994f8e07877501ea7e'] = 'Simula simula simula';
